namespace CodeFirstExistingDatabase
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Employee
    {
        public int Id { get; set; }

        [Required]
        [StringLength(25)]
        public string Name { get; set; }

        public byte? Age { get; set; }

        [StringLength(1)]
        public string Gender { get; set; }

        [StringLength(25)]
        public string EmailAddress { get; set; }

        public int? PhoneNo { get; set; }

        public decimal? Salary { get; set; }

        [Required]
        [StringLength(25)]
        public string City { get; set; }

        [Column(TypeName = "date")]
        public DateTime? DateOfJoining { get; set; }

        public int? DepartmentId { get; set; }

        public virtual Department Department { get; set; }
    }
}
